module.exports = {
  'dbURL': `mongodb+srv://pow:CkqVrdnG40b7KQ4E@trello2.4mx9j.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`,
}